from django.shortcuts import render, redirect
from django.db.models import Q, Count
from .models import League, Team, Player

from . import team_maker

def index(request):
	Team.objects.annotate(num_player = Count('all_players'))
	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
		"baseall_leagues": League.objects.filter(sport = 'Baseball'), 
		"womens_leagues":  League.objects.filter(name__contains = 'Women'),
		"hockey_leagues": League.objects.filter(sport__contains = 'Hockey'),
		"not_football_leagues": League.objects.filter(~Q(sport__contains = 'Football')),
		"all_conferences": League.objects.filter(name__contains = 'conference'),
		"all_atlantic_leagues": League.objects.filter(name__contains = 'Atlantic'),
		"all_dallas_teams": Team.objects.filter(location = 'Dallas'),
		"all_raptors_teams": Team.objects.filter(team_name__contains = 'Raptor'),
		"all_city_teams": Team.objects.filter(location__contains = 'City'),
		"all_T_teams": Team.objects.filter(team_name__startswith = 'T'), 
		"all_ordered_teams": Team.objects.order_by('location'), 
		"all_reverse_ordered_teams": Team.objects.order_by('-team_name'), 
		"all_cooper_players": Player.objects.filter(last_name='Cooper'), 
		"all_joshua_players": Player.objects.filter(first_name='Joshua'), 
		"all_cooper_not_joshua_players": Player.objects.filter(last_name='Cooper').filter(~Q(first_name='Joshua')), 
		"all_alex_or_wyatt_players": Player.objects.filter(Q(first_name='Alexander') | Q(first_name='Wyatt')), 
		"all_teams_atlantic_soccor_conference": Team.objects.filter(league__name='American Baseball Conference'), 
		"all_players_BostonPenguins": Player.objects.filter(curr_team__team_name = 'Blue Jackets'), 
		"all_players_icbc": Player.objects.filter(curr_team__league__name = 'American Baseball Conference'), 
		"all_players_icbc_lopez": Player.objects.filter(curr_team__league__name = 'American Baseball Conference').filter(last_name = 'Lopez'), 
		"all_football_player": Player.objects.filter(curr_team__league__name__contains = 'Football'), 
		"all_sophia": Player.objects.filter(first_name = "Sophia"),
		"all_flores": Player.objects.filter(last_name = "Flores").filter(~Q(curr_team__team_name = "Washington Roughriders")), 
		"all_samuel_evens": Player.objects.get(first_name = "Luke", last_name='Flores').all_teams.all(), 
		"all_ManitobaTigerCats": Team.objects.get(team_name = 'Timberwolves', location = 'Atlanta').all_players.all(),
		"all_team_12": Team.objects.annotate(num_player = Count('all_players'))
	}
	return render(request, "index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")