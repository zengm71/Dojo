from django.shortcuts import render, redirect
from django.db.models import Q
from .models import League, Team, Player

from . import team_maker

def index(request):
	context = {
		"leagues": League.objects.all(),
		"teams": Team.objects.all(),
		"players": Player.objects.all(),
		"baseall_leagues": League.objects.filter(sport = 'Baseball'), 
		"womens_leagues":  League.objects.filter(name__contains = 'Women'),
		"hockey_leagues": League.objects.filter(sport__contains = 'Hockey'),
		"not_football_leagues": League.objects.filter(~Q(sport__contains = 'Football')),
		"all_conferences": League.objects.filter(name__contains = 'conference'),
		"all_atlantic_leagues": League.objects.filter(name__contains = 'Atlantic'),
		"all_dallas_teams": Team.objects.filter(location = 'Dallas'),
		"all_raptors_teams": Team.objects.filter(team_name__contains = 'Raptor'),
		"all_city_teams": Team.objects.filter(location__contains = 'City'),
		"all_T_teams": Team.objects.filter(team_name__startswith = 'T'), 
		"all_ordered_teams": Team.objects.order_by('location'), 
		"all_reverse_ordered_teams": Team.objects.order_by('-team_name'), 
		"all_cooper_players": Player.objects.filter(last_name='Cooper'), 
		"all_joshua_players": Player.objects.filter(first_name='Joshua'), 
		"all_cooper_not_joshua_players": Player.objects.filter(last_name='Cooper').filter(~Q(first_name='Joshua')), 
		"all_alex_or_wyatt_players": Player.objects.filter(Q(first_name='Alexander') | Q(first_name='Wyatt'))

	}
	return render(request, "index.html", context)

def make_data(request):
	team_maker.gen_leagues(10)
	team_maker.gen_teams(50)
	team_maker.gen_players(200)

	return redirect("index")